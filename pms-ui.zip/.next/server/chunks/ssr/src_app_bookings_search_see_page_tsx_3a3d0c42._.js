module.exports = [
"[project]/src/app/bookings/search/see/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Page
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
function Page() {
    const [formData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        bookingNumber: "MX120043-W2200002",
        fullName: "Benjamin Bravo Lopez",
        email: "juanitaolveragomez@gmail.com",
        phone: "4775809876",
        arrivalDate: "17/03/2022",
        departureDate: "18/03/2022",
        status: "Nueva",
        totalWithoutTaxes: "85",
        totalTaxesIncluded: "1",
        ratePlan: "RACK",
        promoCode: "",
        requests: "",
        notes: "",
        description: "DOBLE",
        numberOfRooms: "1",
        adults: "2",
        children: "0",
        cardType: "",
        nameOnCard: "",
        creditCardNumber: "",
        expDate: "",
        code: "",
        agency: ""
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-4 md:p-6 bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-lg font-medium text-gray-900 mb-4 md:mb-6",
                children: "Booking Info"
            }, void 0, false, {
                fileName: "[project]/src/app/bookings/search/see/page.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6",
                children: [
                    {
                        label: "Booking Number",
                        name: "bookingNumber"
                    },
                    {
                        label: "Full Name",
                        name: "fullName"
                    },
                    {
                        label: "Email",
                        name: "email"
                    },
                    {
                        label: "Phone",
                        name: "phone"
                    },
                    {
                        label: "Arrival Date",
                        name: "arrivalDate"
                    },
                    {
                        label: "Departure Date",
                        name: "departureDate"
                    },
                    {
                        label: "Status",
                        name: "status"
                    },
                    {
                        label: "Total Without Taxes",
                        name: "totalWithoutTaxes"
                    },
                    {
                        label: "Total Taxes Included",
                        name: "totalTaxesIncluded"
                    },
                    {
                        label: "Rate Plan",
                        name: "ratePlan"
                    },
                    {
                        label: "Promo Code",
                        name: "promoCode"
                    },
                    {
                        label: "Requests",
                        name: "requests"
                    },
                    {
                        label: "Notes",
                        name: "notes"
                    },
                    {
                        label: "Description",
                        name: "description"
                    },
                    {
                        label: "Number of Rooms",
                        name: "numberOfRooms"
                    },
                    {
                        label: "Adults",
                        name: "adults"
                    },
                    {
                        label: "Children",
                        name: "children"
                    },
                    {
                        label: "Card Type",
                        name: "cardType"
                    },
                    {
                        label: "Name on Card",
                        name: "nameOnCard"
                    },
                    {
                        label: "Credit Card Number",
                        name: "creditCardNumber"
                    },
                    {
                        label: "Exp. Date",
                        name: "expDate"
                    },
                    {
                        label: "Code",
                        name: "code"
                    },
                    {
                        label: "Agency",
                        name: "agency"
                    }
                ].map(({ label, name })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm text-gray-600 mb-1",
                                children: label
                            }, void 0, false, {
                                fileName: "[project]/src/app/bookings/search/see/page.tsx",
                                lineNumber: 90,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full px-2 py-1.5 border border-[#076DB3] rounded-md bg-gray-50 text-gray-900 text-sm truncate",
                                children: formData[name] || '-'
                            }, void 0, false, {
                                fileName: "[project]/src/app/bookings/search/see/page.tsx",
                                lineNumber: 93,
                                columnNumber: 13
                            }, this)
                        ]
                    }, name, true, {
                        fileName: "[project]/src/app/bookings/search/see/page.tsx",
                        lineNumber: 89,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/bookings/search/see/page.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/bookings/search/see/page.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=src_app_bookings_search_see_page_tsx_3a3d0c42._.js.map