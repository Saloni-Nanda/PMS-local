(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_10defdde._.js",
  "static/chunks/src_430bb5a9._.js"
],
    source: "dynamic"
});
