(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_house-keeping_room-status_ac90dab5._.js"
],
    source: "dynamic"
});
