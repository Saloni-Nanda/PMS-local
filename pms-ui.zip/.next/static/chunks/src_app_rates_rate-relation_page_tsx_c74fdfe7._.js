(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_fcbf8524._.js",
  "static/chunks/src_d9d02a0f._.js",
  "static/chunks/node_modules_react-datepicker_dist_react-datepicker_5992d360.css"
],
    source: "dynamic"
});
