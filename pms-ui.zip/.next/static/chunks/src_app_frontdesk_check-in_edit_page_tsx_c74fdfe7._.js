(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_414874db._.js",
  "static/chunks/node_modules_599ca307._.js"
],
    source: "dynamic"
});
