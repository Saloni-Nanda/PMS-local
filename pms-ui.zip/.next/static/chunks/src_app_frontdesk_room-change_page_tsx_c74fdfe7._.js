(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_frontdesk_room-change_acd3c00a._.js",
  "static/chunks/node_modules_7f6c2b5b._.js"
],
    source: "dynamic"
});
