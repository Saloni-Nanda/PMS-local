(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_frontdesk_advance-payments_see-advance-payments_page_tsx_d5be5626._.js"
],
    source: "dynamic"
});
