(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_date-fns_22fae1a5._.js",
  "static/chunks/node_modules_9be2cb6b._.js",
  "static/chunks/node_modules_react-datepicker_dist_index_es_4982a1c7.js",
  "static/chunks/node_modules_@headlessui_react_dist_eca6dde4._.js",
  "static/chunks/node_modules_9362c262._.js",
  "static/chunks/src_6e28c1c5._.js",
  "static/chunks/node_modules_react-datepicker_dist_react-datepicker_5992d360.css"
],
    source: "dynamic"
});
