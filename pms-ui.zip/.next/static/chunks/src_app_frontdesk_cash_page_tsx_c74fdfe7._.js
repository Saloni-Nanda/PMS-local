(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_079fbc5c._.js",
  "static/chunks/src_66256bf9._.js",
  "static/chunks/node_modules_react-datepicker_dist_react-datepicker_5992d360.css"
],
    source: "dynamic"
});
